<?php
$db = new mysqli();
$db->connect("localhost","root","","bitdb");

