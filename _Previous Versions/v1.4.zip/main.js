function openContractor() {
    document.getElementById("contractorAssignmentTable").style.display = "block";
}

function assignContractor() {
    document.getElementById("contractorAssignmentTable").style.display = "none";
}

function openProfileForm(clicked_id) {
    var displayStatus = document.getElementById("profileWrapper").style.display;

    if ((displayStatus === "none" && clicked_id === "login") || (displayStatus === "" && clicked_id === "login")) {
        document.getElementById("profileWrapper").style.display = "block";
    } else {
        document.getElementById("profileWrapper").style.display = "none";
    }

}
