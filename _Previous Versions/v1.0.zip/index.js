function openForm() {
    var displayStatus = document.getElementById("formWrapper").style.display;

    if (displayStatus == "block") {
        document.getElementById("formWrapper").style.display = "none";
    } else {
        document.getElementById("formWrapper").style.display = "block";
    }

}

function showImage() {
    var wrapperWidth = document.getElementById("mainWrapper").style.width;

    if (wrapperWidth < 300) {
        document.getElementById("blackImage").style.display = "none";
    } else {
        document.getElementById("blackImage").style.display = "inline"
    }
}