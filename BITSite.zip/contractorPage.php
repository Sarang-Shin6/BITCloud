<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Contractor Page</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="main.css">
        <script src="main.js"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
    <header>
        <nav class="grey-bg header" style="width:100%;height:70px;">
            <a href="index.html"><img class="logo" src="images/BITLogoLone.png" alt="BIT LOGO" height="70px" style="margin-left:10px;"/></a>
        </nav>
        <div class="profilePositionContainer">
            <p class="profile orange-fore" id="login">WELCOME [FIRSTNAME]!</p>
        </div>
    </header>
    <section class="mainSection">
        <div class="infoCardWrapper">
            <div class="informationCard">
                <div class="informationCardHeader">
                <h1 class="informationCardH1">JOB REQUESTS</h1>
                </div>

                <?php
                $db = new mysqli();
                $db->connect("localhost","root","","bitdb");

                $result = mysqli_query($db, "call usp_Cloud_ContractorAssignRequest(2)");
                echo '
                    <table role="grid"  class="tableFormat" style="width:98%">
                    <tr class="tableHeader">
                        <th class="jobRequestHeader" style="width: 10%;">Start Date</th>
                        <th class="jobRequestHeader" style="width: 10%;">Company</th>
                        <th class="jobRequestHeader" style="width: 7%;">Client First Name</th>
                        <th class="jobRequestHeader" style="width: 7%;">Client Last Name</th>
                        <th class="jobRequestHeader" style="width: 7%;">Client Phone Number</th>
                        <th class="jobRequestHeader" style="width: 10%;">Branch</th> 
                        <th class="jobRequestHeader" style="width: 10%;">Street</th> 
                        <th class="jobRequestHeader" style="width: 5%;">Suburb</th>
                        <th class="jobRequestHeader" style="width: 5%;">State</th> 
                        <th class="jobRequestHeader" style="width: 5%;">Postcode</th> 
                        <th style="width: 16%;">Description</th>
                        <th class="jobRequestHeader" style="width: 10%;">Job Category</th>
                        <th class="jobRequestHeader" style="width: 5%;">Action</th>
                    </tr><tbody>';
                while ($row = mysqli_fetch_array($result)) {
                    echo '<tr>
                            <td>' . $row["PreferredStartDate"] . '</td>
                            <td>' . $row["Name"] . '</td>
                            <td>' . $row["FirstName"] . '</td>
                            <td>' . $row["LastName"] . '</td> 
                            <td>' . $row["Phone"] . '</td> 
                            <td>' . $row["Branch"] . '</td>
                            <td>' . $row["Street"] . '</td>
                            <td>' . $row["Suburb"] . '</td>
                            <td>' . $row["State"] . '</td>
                            <td>' . $row["Postcode"] . '</td>
                            <td>' . $row["description"] . '</td>
                            <td>' . $row["Description"] . '</td>
                            <td><button style="margin:2px auto;width: 60px;">Accept</button><button style="margin:2px auto; width:60px;">Decline</button></td>
                            </tr>';
                }
                echo '</tbody></table></div>'
                ?>

            <div class="informationCard">
                    <div class="informationCardHeader">
                    <h1 class="informationCardH1">JOBS IN PROGRESS</h1>
                    </div>

                <?php
                $db = new mysqli();
                $db->connect("localhost","root","","bitdb");

                $result = mysqli_query($db, "call usp_Cloud_ContractorJobs(2)");
                echo '
                    <table role="grid"  class="tableFormat" style="width:98%">
                    <tr class="tableHeader">
                        <th class="jobRequestHeader" style="width: 10%;">Start Date</th>
                        <th class="jobRequestHeader" style="width: 10%;">Job ID</th>
                        <th class="jobRequestHeader" style="width: 10%;">Company</th>
                        <th class="jobRequestHeader" style="width: 7%;">Client First Name</th>
                        <th class="jobRequestHeader" style="width: 7%;">Client Last Name</th> 
                        <th class="jobRequestHeader" style="width: 7%;">Client Phone Number</th> 
                        <th class="jobRequestHeader" style="width: 10%;">Branch</th> 
                        <th class="jobRequestHeader" style="width: 10%;">Street</th> 
                        <th class="jobRequestHeader" style="width: 5%;">Suburb</th>
                        <th class="jobRequestHeader" style="width: 5%;">State</th> 
                        <th class="jobRequestHeader" style="width: 5%;">Postcode</th> 
                        <th style="width: 16%;">Description</th>
                        <th class="jobRequestHeader" style="width: 10%;">Job Category</th>
                        <th class="jobRequestHeader" style="width: 5%;">Status</th>
                    </tr><tbody>';
                while ($row = mysqli_fetch_array($result)) {
                    echo '<tr>
                            <td>' . $row["PreferredStartDate"] . '</td>
                            <td>' . $row["Name"] . '</td>
                            <td>' . $row["FirstName"] . '</td>
                            <td>' . $row["LastName"] . '</td>
                            <td>' . $row["Phone"] . '</td>  
                            <td>' . $row["Branch"] . '</td>
                            <td>' . $row["Street"] . '</td>
                            <td>' . $row["Suburb"] . '</td>
                            <td>' . $row["State"] . '</td>
                            <td>' . $row["Postcode"] . '</td>
                            <td>' . $row["description"] . '</td>
                            <td>' . $row["Description"] . '</td>';
                        if ($row["StatusID"] == 5) {
                            echo '<td><button>Complete</button></td>';
                        } else {
                            echo '<td>' . $row["StatusID"] . '</td>';
                        };
                        echo '</tr';
                }
                echo '</tbody></table></div>'
                ?>


        </div>
    </section>
    <footer>
        <div id="footerWrapper">
            <p>&copy; 2019 BIT - Business Information Technology Pty Ltd<br/>
                Phone: (02) 131 601<br/>
                Address: 205 Peats Ferry Rd, Hornsby NSW 2077<br/>
                Email: contact-us@bit.com</p>
        </div>
    </footer>
</body>

</html>