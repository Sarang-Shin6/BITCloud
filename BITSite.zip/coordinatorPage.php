<!DOCTYPE <!DOCTYPE html>
<html lang="en">
    <head>
        <title>Welcome to BIT</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="main.css">
        <script src="main.js"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
    <header>
        <nav class="grey-bg header" style="width:100%;height:70px;">
            <a href="index.html"><img class="logo" src="images/BITLogoLone.png" alt="BIT LOGO" height="70px" style="margin-left:10px;"/></a>
        </nav>
        <div class="profilePositionContainer">
            <p class="profile orange-fore" id="login">WELCOME [FIRSTNAME]!</p>
        </div>
    </header>
    <section class="mainSection">
        <div class="infoCardWrapper">
            <div class="informationCard">
                <div class="informationCardHeader">
                <h1 class="informationCardH1">CONTRACTOR ASSIGNMENT </h1>
                </div>
                <?php
                    $db = new mysqli();
                    $db->connect("localhost","root","","bitdb");

                    $result = mysqli_query($db, "call usp_Cloud_CoordinatorGetAssignments(2)");
                    echo '
                    <table role="grid"  class="tableFormat"><tr class="tableHeader">
                    <th class="jobRequestHeader" style="width: 7%;">Job ID</th>
                    <th class="jobRequestHeader" style="width: 5%;">ClientID</th>
                    <th class="jobRequestHeader" style="width: 5%;">CompanyID</th>
                    <th class="jobRequestHeader" style="width: 13%;">Company Name</th>
                    <th class="jobRequestHeader" style="width: 8%;">Branch</th>
                    <th class="jobRequestHeader" style="width: 32%;">Description</th>
                    <th class="jobRequestHeader" style="width: 10%;">Date</th>
                    <th class="jobRequestHeader" style="width: 13%;">Estimated Duration</th>
                    <th class="jobRequestHeader" style="width: 6%;">Contractor</th>
                    </tr><tbody>';
                        while ($row = mysqli_fetch_array($result)) {
                            echo '<tr>
                            <td>' . $row["JobID"] . '</td>
                            <td>' . $row["ClientID"] . '</td>
                            <td>' . $row["CompanyID"] . '</td> 
                            <td>' . $row["Name"] . '</td>
                            <td>' . $row["Branch"] . '</td>
                            <td>' . $row["Description"] . '</td>
                            <td>' . $row["PreferredStartDate"] . '</td>
                            <td>' . $row["EstimatedDuration"] . '</td>
                            <td><Button type="submit" onclick="openContractor()">Assign</Button></td>
                            </tr>';
                        }
                echo '</tbody></table></div>'
                ?>

                <div class="informationCard" style="display:none;" id="contractorAssignmentTable">
                <div class="informationCardHeader">
                <h1 class="informationCardH1">CONTRACTOR LIST -- Too be Hidden/Open on Selection</h1>
                </div>
                    <?php
                    $db = new mysqli();
                    $db->connect("localhost","root","","bitdb");

                    $result = mysqli_query($db, "call usp_Cloud_CoordinatorGetContractors()");
                    echo '
                    <table role="grid"  class="tableFormat" style="width:98%">
                    <tr class="tableHeader">
                        <th class="jobRequestHeader" style="width: 13%;">ContractorID</th>
                        <th class="jobRequestHeader" style="width: 30%;">First Name</th>
                        <th class="jobRequestHeader" style="width: 30%;">Last Name</th>
                        <th class="jobRequestHeader" style="width: 14%;">Rating</th>
                        <th class="jobRequestHeader" style="width: 13%;">Select</th>
                    </tr><tbody>';
                    while ($row = mysqli_fetch_array($result)) {
                        echo '<tr>
                            <td>' . $row["ContractorID"] . '</td>
                            <td>' . $row["Firstname"] . '</td>
                            <td>' . $row["Lastname"] . '</td> 
                            <td>' . $row["AverageRating"] . '</td>
                            <td><Button type="submit" onclick="assignContractor()">Assign</Button></td>
                            </tr>';
                    }
                    echo '</tbody></table></div>'
                    ?>

        <div class="informationCard">
                <div class="informationCardHeader">
                <h1 class="informationCardH1">JOB STATUS</h1>
                </div>
            <?php
            $db = new mysqli();
            $db->connect("localhost","root","","bitdb");

            $result = mysqli_query($db, "call usp_Cloud_CoordinatorJobStatus(2)");
            echo '
                    <table role="grid"  class="tableFormat" style="width:98%">
                    <tr class="tableHeader">
                        <th class="jobRequestHeader" style="width: 5%;">JobID</th>
                        <th class="jobRequestHeader" style="width: 5%;">ClientID</th>
                        <th class="jobRequestHeader" style="width: 5%;">CompanyID</th>
                        <th class="jobRequestHeader" style="width: 10%;">Company Name</th>
                        <th class="jobRequestHeader" style="width: 10%;">Company Branch</th>
                        <th class="jobRequestHeader" style="width: 10%;">Start Date</th>
                        <th class="jobRequestHeader" style="width: 5%;">ContractorID</th>
                        <th class="jobRequestHeader" style="width: 10%;">Contractor First Name</th>
                        <th class="jobRequestHeader" style="width: 10%;">Contractor Last Name</th>
                        <th class="jobRequestHeader" style="width: 10%;">KMs Logged</th>
                        <th class="jobRequestHeader" style="width: 10%;">Hours Worked</th>
                        <th class="jobRequestHeader" style="width: 10%;">Status</th>
                    </tr><tbody>';
            while ($row = mysqli_fetch_array($result)) {
                echo '<tr>
                            <td>' . $row["JobID"] . '</td>
                            <td>' . $row["ClientID"] . '</td>
                            <td>' . $row["CompanyID"] . '</td> 
                            <td>' . $row["Name"] . '</td>
                            <td>' . $row["Branch"] . '</td>
                            <td>' . $row["StartDate"] . '</td>
                            <td>' . $row["ContractorID"] . '</td> 
                            <td>' . $row["FirstName"] . '</td>
                            <td>' . $row["LastName"] . '</td>
                            <td>' . $row["LoggedKm"] . '</td>
                            <td>' . $row["Duration"] . '</td>';
                if ($row["Description"] === "Completed") {
                    echo'<td><Button type="submit">Verify</Button></td></tr>';
                } else {
                    echo'<td>' . $row["Description"] . '</td></tr>';
                };

            }
            echo '</tbody></table></div>'
            ?>

        </div>
    </section>
    <footer>
        <div id="footerWrapper">
            <p>&copy; 2019 BIT - Business Information Technology Pty Ltd<br/>
                Phone: (02) 131 601<br/>
                Address: 205 Peats Ferry Rd, Hornsby NSW 2077<br/>
                Email: contact-us@bit.com</p>
        </div>
    </footer>
</body>

</html>